import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mycomp',
  template:'<h1>verer</h1>'
  
})
export class MycompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
